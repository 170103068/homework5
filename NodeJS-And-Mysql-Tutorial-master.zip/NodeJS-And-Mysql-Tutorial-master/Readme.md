**NodeJS + MySQL Database Connection Tutorial**


Learn how to do NodeJS + ExpressJS + MySQL database connection using MySQL database and querying data from the database.

Github Repo - https://github.com/amithorakeri/NodeJS-And-Mysql-Tutorial


Video Tutorial link for this repository - https://youtu.be/XL73fnBF6pw
